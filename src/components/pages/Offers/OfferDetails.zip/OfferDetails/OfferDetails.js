import React from "react";
import Layout from "../../../Layout/Layout";
import {Grid} from '@mui/material';
import OfferDetail from "./Elements/OfferDetail";
import "./OfferDetails.scss";
import CustomerPayout from "./Elements/CustomerPayout";


const OfferDetails = () => {
    return(
        <Layout title="Offer Details">
            <div id="OfferDetails">
            <Grid container spacing={5}>
                <Grid item lg={6}>
                    <div className='offer_details'>
                        <OfferDetail />
                        <br />
                        <CustomerPayout />
                    </div>
                </Grid>
                {/* <Grid item lg={6}>
                    <div className='Table__item'>
                        hello
                    </div>
                </Grid> */}
            </Grid>
            </div>
        </Layout>
    )
}


export default OfferDetails;