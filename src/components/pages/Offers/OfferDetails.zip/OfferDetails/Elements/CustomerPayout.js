import React from 'react';
import { Link } from 'react-router-dom';
import { CreateIcon, DeleteIcon } from '../../../../../assets/Icons';
import ArrowDropDownIcon from '@mui/icons-material/ArrowDropDown';
import Table from 'react-bootstrap/Table';
import photo from '../../../../../assets/Ellipse 5.png';

const CustomerPayout = () => {
    return(
        <div id="customerPayout">
            <h3>affiliate custom payout <Link to="/" >{CreateIcon} create</Link></h3>
            <Table responsive="lg">
                <thead>
                <tr>
                    <th>Affiliate <ArrowDropDownIcon /></th>
                    <th>Type <ArrowDropDownIcon/></th>
                    <th>Revenue <ArrowDropDownIcon/></th>
                    <th>Payout <ArrowDropDownIcon/></th>
                    <th>Action</th>
                </tr>
                </thead>
                <tbody>
                <tr>
                    <td>
                    <img src={photo}  alt={photo} />
                    new tR- smart link (US) only
                    </td>
                    <td>
                        CPA
                    </td>
                    <td>
                        $50.00
                    </td>
                    <td>
                        $50
                    </td>
                    <td>
                        <Link to="/"> {DeleteIcon} Delete </Link>
                    </td>
                </tr>
                </tbody>
            </Table>
        </div>

    );
}


export default CustomerPayout;






