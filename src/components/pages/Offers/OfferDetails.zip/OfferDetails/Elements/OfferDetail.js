import React from "react";
import logo from '../../../../../assets/Rectangle 42.png';


const OfferDetail = () => {
    return(
        <div className="OfferDetail">
            <h4>Offer Details</h4>
            <img src={logo}  alt={logo} />
            <ul>
                <li>advertiser: <span>maxbounty private</span></li>
                <li>Offer Name: <span>new tR- smart link (US) only</span></li>
                <li>offer preview uRL: <span>https://health.clevelandclinic.org/do-fat-burners-work</span></li>
                <li>daily cap: <span>50</span></li>
                <li>Country: <span>USA</span></li>
                <li>default payout: <span>$24</span></li>
                <li>expire date: <span>01 jan, 2024</span></li>
                <li>Description: <span>Millions of consumers use TransUnion’s products to manage their credit online & through our apps, protect their identity day & night, Offer converts on paid subscription. Users will then be re-billed for a monthly subscription 66%</span></li>
            </ul>
        </div>
    );
}


export default OfferDetail;
